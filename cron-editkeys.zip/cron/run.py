# 这是一个示例 Python 脚本。

# 按 Shift+F10 执行或将其替换为您的代码。
# 按 双击 Shift 在所有地方搜索类、文件、工具窗口、操作和设置。
from PIL import Image
import os
import shutil

logpath = os.path.join(os.getcwd(), 'jindu.txt')


def start(source_dir, dst_path, moshi):
    # 创建目标目录
    if not os.path.exists(dst_path):
        os.makedirs(dst_path)
    nums = 0
    for dirpath, dirnames, filenames in os.walk(source_dir):
        if dirpath.find('99999')>-1:
            continue
        for filename in filenames:
            if filename.lower().endswith(('.jpg', '.jpeg', '.png', '.bmp')):
                nums += 1
    with open(logpath, 'w') as f:
        f.write('0')

    # 遍历文件夹及子文件夹下的所有图片
    ing = 0
    for dirpath, dirnames, filenames in os.walk(source_dir):
        print('dirpath=',dirpath)
        if dirpath.find('99999')>-1:
            continue
        for filename in filenames:
            if filename.lower().endswith(('.jpg', '.jpeg', '.png', '.bmp')):
                # 打开图片
                filepath = os.path.join(dirpath, filename)
                image = Image.open(filepath)

                # 裁剪图片
                width, height = image.size
                # 保存图片
                dst_dirpath = dirpath.replace(source_dir, dst_path)  # 获取目标目录中的子目录路径
                if height >= width:
                    ing += 1
                    print(f"进度{ing}/{nums}")
                    with open(logpath, 'w') as f:
                        f.write(str(round(100 * ing / nums, 2)))
                    newname=os.path.splitext(filename)[0]+os.path.splitext(filename)[1]
                    os.makedirs(dst_dirpath, exist_ok=True)
                    shutil.copy(filepath,os.path.join(dst_dirpath, newname))
                    continue
                left = 0
                right = width - left
                mid = width // 2
                left_image = image.crop((left, 0, mid, height))
                right_image = image.crop((mid, 0, right, height))


                os.makedirs(dst_dirpath, exist_ok=True)  # 创建目标目录的子目录，如果不存在则创建
                leftname='-1'
                rightname='-2'
                if moshi==2:
                    leftname='-2'
                    rightname='-1'
                left_filename = os.path.splitext(filename)[0] + leftname + os.path.splitext(filename)[1]
                left_filepath = os.path.join(dst_dirpath, left_filename)
                if os.path.exists(left_filepath):
                    os.remove(left_filepath)
                left_image.save(left_filepath)

                right_filename = os.path.splitext(filename)[0] + rightname + os.path.splitext(filename)[1]
                right_filepath = os.path.join(dst_dirpath, right_filename)
                if os.path.exists(right_filepath):
                    os.remove(right_filepath)
                right_image.save(right_filepath)
                ing += 1
                print(f"进度{ing}/{nums},img={right_filepath}")
                with open(logpath, 'w') as f:
                    f.write(str(round(100 * ing / nums, 2)))
