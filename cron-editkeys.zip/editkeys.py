# 修改 机翻软件key和升级
import os
import shutil

import PySimpleGUI as sg
import tkinter.messagebox as msgbox

import win32con
import win32gui
import win32api
import subprocess
import zipfile
import re

root_dir = os.getcwd()
root_dirname = 'manga-image-translator-main'


# 读取已有的key
def readhas():
    filepath = os.path.join(root_dir, 'manga_translator/translators/keys.py')
    if not os.path.exists(filepath):
        return {
            "OPENAI_API_KEY": "",
            "OPENAI_HTTP_PROXY": "",
            "BAIDU_APP_ID": "",
            "BAIDU_SECRET_KEY": "",
            "YOUDAO_APP_KEY": "",
            "YOUDAO_SECRET_KEY": ""
        }
    # 读取代码
    with open(filepath, 'r') as f:
        code = f.read()

    # 定义正则表达式，匹配以大写字母开头的变量名和变量值
    pattern = re.compile(r'([A-Z_]+)\s*=\s*os.getenv\(\W[A-Za-z0-9_]+\W,\s*?[\"\']+?(.*?)[\'\"]+?\)')

    # 在代码中搜索匹配正则表达式的内容，并将结果存储到字典 variables 中
    variables = {}
    for match in pattern.finditer(code):
        variables[match.group(1)] = match.group(2)

    # 输出结果
    print(variables)
    return variables


# 解压
def jieya(zip_file):
    # 解压缩文件
    with zipfile.ZipFile(zip_file, 'r') as zip_ref:
        for info in zip_ref.infolist():
            # 当解压缩的文件已存在于目标目录中时，不提示并覆盖原文件
            extract_path = os.path.join(root_dir, info.filename)
            if os.path.exists(extract_path):
                os.remove(extract_path)
            zip_ref.extract(info, root_dir)

    for root, dirs, files in os.walk(os.path.join(root_dir, root_dirname)):
        # 拼接目标目录
        relpath = os.path.relpath(root, start=os.path.join(root_dir, root_dirname))

        # 移动所有子文件夹
        for d in dirs:
            # src_path = os.path.join(root, d)
            dst_path = os.path.join(root_dir, relpath, d)
            print('---- ', dst_path)
            os.makedirs(dst_path, exist_ok=True)
            # if not os.path.exists(dst_path):
            # shutil.move(src_path, dst_path)
        # return
        # 移动所有子文件夹
        for f in files:
            src_path = os.path.join(root, f)
            dst_path = os.path.join(root_dir, relpath, f)
            # continue
            if os.path.exists(dst_path):
                os.remove(dst_path)
            shutil.move(src_path, dst_path)
            print(src_path, ' =====  ', dst_path)
    # 删除 root_dirname 目录
    shutil.rmtree(os.path.join(root_dir, root_dirname))


# 读取已有额
oldvar = readhas()

layout = [[
    sg.Text('修改keys.py, 从github下载解压包覆盖到根目录后,执行下方按钮"提交修改"')
],
    [
        sg.Text('chatGPT', size=(10, 1)),
        sg.Input(key="openai_api_key", expand_x=True, default_text=oldvar['OPENAI_API_KEY']),
        sg.Text('Proxy', size=(10, 1)),
        sg.Input(key="openai_http_proxy", expand_x=True, default_text=oldvar['OPENAI_HTTP_PROXY'])],
    [
        sg.Text('Baidu_id', size=(10, 1)),
        sg.Input(key="baidu_app_id", expand_x=True, default_text=oldvar['BAIDU_APP_ID']),
        sg.Text('Baidu_key', size=(10, 1)),
        sg.Input(key="baidu_secret_key", expand_x=True, default_text=oldvar['BAIDU_SECRET_KEY'])],
    [
        sg.Text('Youdao_key', size=(10, 1)),
        sg.Input(key="youdao_app_key", expand_x=True, default_text=oldvar['YOUDAO_APP_KEY']),
        sg.Text('Youdao_key', size=(10, 1)),
        sg.Input(key="youdao_secret_key", expand_x=True, default_text=oldvar['YOUDAO_SECRET_KEY'])
    ],
    [
        sg.Input(key="zippath", expand_x=True),
        sg.FileBrowse("导入zip包", target="zippath")
    ],
    [
        sg.Button('修改key', key="start"),
        sg.Button('升级包', key="up"),
    ]
]

# Create the Window
window = sg.Window('管理trans', layout, resizable=True)

while True:
    event, values = window.read(timeout=100)
    if event == sg.WIN_CLOSED or event == 'Cancel':  # if user closes window or clicks cancel
        break
    if event == 'start' or event == 'up':
        # 先关闭 查找窗口句柄
        handle = win32gui.FindWindow(None, 'start.bat')
        if handle != 0:
            # 发送关闭消息
            win32api.PostMessage(handle, win32con.WM_CLOSE, 0, 0)
    if event == 'up':
        # 升级
        zip_file = values['zippath']
        if not os.path.exists(zip_file):
            msgbox.showerror("压缩包不存在", message="先去github下载zip包", parent=window.TKroot)
            continue
        else:
            jieya(zip_file)
            # 修改 127.0.0.1
            with open(os.path.join(root_dir, 'manga_translator/manga_translator.py'), 'r') as f:
                text = f.read()
            with open(os.path.join(root_dir, 'manga_translator/manga_translator.py'), 'w') as f:
                f.write(text.replace(r'http://{self.host}', 'http://127.0.0.1'))
    if event == 'start' or event == 'up':
        content = [
            f'YOUDAO_APP_KEY = os.getenv("YOUDAO_APP_KEY", "{values["youdao_app_key"]}")\n',
            f'YOUDAO_SECRET_KEY = os.getenv("YOUDAO_SECRET_KEY", "{values["youdao_secret_key"]}")\n',
            f'BAIDU_APP_ID = os.getenv("BAIDU_APP_ID", "{values["baidu_app_id"]}")\n',
            f'BAIDU_SECRET_KEY = os.getenv("BAIDU_SECRET_KEY", "{values["baidu_secret_key"]}")\n',
            f'OPENAI_API_KEY = os.getenv("OPENAI_API_KEY","{values["openai_api_key"]}")\n',
            f'OPENAI_HTTP_PROXY = os.getenv("OPENAI_HTTP_PROXY","{values["openai_http_proxy"]}")\n',
        ]
        with open(os.path.join(root_dir, 'manga_translator/translators/keys.py'), 'r') as f:
            lines = f.readlines()
            filtered_lines = [line for line in lines if not (line.startswith('YOUDAO_APP_KEY')
                                                             or line.startswith('YOUDAO_SECRET_KEY')
                                                             or line.startswith('BAIDU_APP_ID')
                                                             or line.startswith('BAIDU_SECRET_KEY')
                                                             or line.startswith('OPENAI_API_KEY')
                                                             or line.startswith('OPENAI_HTTP_PROXY'))]
            filtered_lines += content

        with open(os.path.join(root_dir, 'manga_translator/translators/keys.py'), 'w') as f:
            f.writelines(filtered_lines)
        # 再启动
        subprocess.Popen(['start', 'cmd', '/k', os.path.join(root_dir, 'start.bat')], shell=True)
        if event == 'start':
            title = '修改成功'
        else:
            title = '升级成功'
        msgbox.showinfo(title, message="如果重启未生效,请手动重启start.bat", parent=window.TKroot)

window.close()
