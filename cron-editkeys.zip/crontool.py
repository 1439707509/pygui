# 裁剪图片 ，左右1-2 2-1 裁剪
import os
import PySimpleGUI as sg
import tkinter.messagebox as msgbox
import time
import threading

import cron

logpath=os.path.join(os.getcwd(),'jindu.txt')

    # cron.run.start(r'C:\Users\c1\Documents\Tencent Files\2124455076\FileRecv\1(2)\1\1',r'C:\Users\c1\Documents\Tencent Files\2124455076\FileRecv\haha')
# sg.theme('DarkAmber')   # Add a touch of color
# All the stuff inside your window.
hasstart=False
layout = [  [
                sg.Text('裁剪图片'),
                sg.Text(key="jindutext"),
                sg.Radio('1-2模式','moshi',default=False,key="moshi1"),
                sg.Radio('2-1模式','moshi',default=True,key="moshi2"),
             ],
            [sg.Input(key="source_dir", expand_x=True), sg.FolderBrowse(button_text="输入文件夹",target="source_dir")],
            [sg.Input(key="dist_dir", expand_x=True), sg.FolderBrowse(button_text="输出文件夹",target="dist_dir")],
            [sg.Button('开始',key="start")] ]

# Create the Window
window = sg.Window('裁剪图片', layout,resizable=True)
# Event Loop to process "events" and get the "values" of the inputs

lasttime=time.time()
while True:
    event, values = window.read(timeout=100)
    if event == sg.WIN_CLOSED or event == 'Cancel': # if user closes window or clicks cancel
        break
    if event=="start":
        if hasstart:
            continue
        if not values['source_dir'] :
            msgbox.showerror(title='出错了', message='必须选择输入文件夹！')
            continue
        else:
            dist_dir=values['dist_dir']
            if not dist_dir:
                dist_dir=values['source_dir']+"/99999"
                if not os.path.join(dist_dir):
                    os.makedirs(dist_dir)
            hasstart=True
            window['start'].update("执行中")
            with open(logpath,'w') as f:
               f.write("0")
            # 模式
            print(values['moshi1'],values['moshi2'])
            if values['moshi1']:
                moshi=1
            else:
                moshi=2
            print(values['source_dir'],dist_dir,moshi)
            threading.Thread(target=cron.run.start,args=(values['source_dir'],dist_dir,moshi)).start()
    if hasstart and time.time()-lasttime>3:
        print(f"超过5s了 {lasttime}")
        lasttime=time.time()
        with open(logpath,'r') as f:
            jindu=round(float(f.read()),2)
            if jindu>=100:
                hasstart=False
                window['start'].update("执行结束")
            window["jindutext"].update(f"进度{jindu}%")
window.close()
